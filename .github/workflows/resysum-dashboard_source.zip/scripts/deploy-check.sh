
#!/bin/bash

# RESYSUM Dashboard Deployment Check Script
# This script verifies the deployment is ready and working correctly

set -e

echo "🚀 Starting RESYSUM Dashboard deployment verification..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Check if required environment variables are set
echo "📋 Checking environment variables..."
if [ -z "$DATABASE_URL" ]; then
    print_error "DATABASE_URL is not set"
    exit 1
fi
print_status "DATABASE_URL is configured"

if [ -z "$NEXTAUTH_SECRET" ]; then
    print_error "NEXTAUTH_SECRET is not set"
    exit 1
fi
print_status "NEXTAUTH_SECRET is configured"

if [ -z "$NEXTAUTH_URL" ]; then
    print_error "NEXTAUTH_URL is not set"
    exit 1
fi
print_status "NEXTAUTH_URL is configured"

# Generate Prisma client
echo "🔧 Generating Prisma client..."
npx prisma generate
print_status "Prisma client generated successfully"

# Run database migrations
echo "🗄️ Running database migrations..."
npx prisma migrate deploy
print_status "Database migrations completed"

# Check database connection
echo "🔌 Testing database connection..."
npx prisma db execute --stdin <<< "SELECT 1;" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    print_status "Database connection successful"
else
    print_error "Database connection failed"
    exit 1
fi

# Build the application
echo "🏗️ Building Next.js application..."
npm run build
if [ $? -eq 0 ]; then
    print_status "Application built successfully"
else
    print_error "Build failed"
    exit 1
fi

# Check if build output exists
if [ -d ".next" ]; then
    print_status "Build output directory exists"
else
    print_error "Build output directory not found"
    exit 1
fi

# Seed database (optional - only if seed script exists)
if [ -f "scripts/seed.ts" ] || [ -f "prisma/seed.ts" ]; then
    echo "🌱 Seeding database with initial data..."
    npm run db:seed 2>/dev/null || print_warning "Seeding skipped (no seed script or already seeded)"
fi

echo ""
echo "🎉 Deployment verification completed successfully!"
echo "📊 RESYSUM Dashboard is ready for production deployment"
echo ""
echo "Next steps:"
echo "1. Push your code to GitHub"
echo "2. Connect your repository to Vercel"
echo "3. Set environment variables in Vercel dashboard"
echo "4. Deploy to production"
echo ""
