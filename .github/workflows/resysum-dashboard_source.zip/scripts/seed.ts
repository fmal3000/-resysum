
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create demo user
  const hashedPassword = await bcrypt.hash('johndoe123', 10)
  
  const user = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      password: hashedPassword,
      name: 'John Doe',
      role: 'admin',
    },
  })

  console.log('✅ Created demo user')

  // Create buyers
  const buyers = await Promise.all([
    prisma.buyer.create({
      data: {
        name: 'Smith Investment Group',
        email: 'contact@smithinvestments.com',
        phone: '(555) 234-5678',
        preferredAreas: ['Dallas', 'Houston'],
        maxBudget: 500000,
        minBedrooms: 2,
        propertyTypes: ['SFH', 'Duplex'],
        isActive: true,
        notes: 'Prefers properties in up-and-coming neighborhoods',
      },
    }),
    prisma.buyer.create({
      data: {
        name: 'Houston Properties LLC',
        email: 'deals@houstonprops.com',
        phone: '(555) 345-6789',
        preferredAreas: ['Houston', 'Austin'],
        maxBudget: 350000,
        minBedrooms: 3,
        propertyTypes: ['SFH'],
        isActive: true,
        notes: 'Quick closings, cash buyers',
      },
    }),
    prisma.buyer.create({
      data: {
        name: 'Austin Investors',
        email: 'info@austininvestors.com',
        phone: '(555) 456-7890',
        preferredAreas: ['Austin', 'San Antonio'],
        maxBudget: 400000,
        minBedrooms: 2,
        propertyTypes: ['SFH', 'Townhouse'],
        isActive: true,
        notes: 'Interested in fix-and-flip opportunities',
      },
    }),
    prisma.buyer.create({
      data: {
        name: 'Alamo Real Estate',
        email: 'buying@alamore.com',
        phone: '(555) 567-8901',
        preferredAreas: ['San Antonio'],
        maxBudget: 250000,
        minBedrooms: 2,
        propertyTypes: ['SFH', 'Duplex'],
        isActive: true,
        notes: 'Rental property focused',
      },
    }),
  ])

  console.log('✅ Created buyers')

  // Create properties
  const properties = await Promise.all([
    prisma.property.create({
      data: {
        address: '123 Main Street',
        city: 'Dallas',
        state: 'TX',
        zipCode: '75201',
        propertyType: 'Single Family',
        bedrooms: 3,
        bathrooms: 2.5,
        squareFeet: 1850,
        yearBuilt: 1995,
        lotSize: 0.25,
        arv: 285000,
        estimatedRepair: 35000,
        investmentScore: 8.2,
        status: 'analyzed',
        notes: 'Great neighborhood, minor cosmetic repairs needed',
        userId: user.id,
      },
    }),
    prisma.property.create({
      data: {
        address: '456 Oak Avenue',
        city: 'Houston',
        state: 'TX',
        zipCode: '77001',
        propertyType: 'Duplex',
        bedrooms: 4,
        bathrooms: 3,
        squareFeet: 2200,
        yearBuilt: 1988,
        lotSize: 0.30,
        arv: 320000,
        estimatedRepair: 28000,
        investmentScore: 7.8,
        status: 'contacted',
        notes: 'Duplex with rental income potential',
        userId: user.id,
      },
    }),
    prisma.property.create({
      data: {
        address: '789 Pine Street',
        city: 'Austin',
        state: 'TX',
        zipCode: '78701',
        propertyType: 'Single Family',
        bedrooms: 2,
        bathrooms: 1,
        squareFeet: 1200,
        yearBuilt: 1975,
        lotSize: 0.18,
        arv: 245000,
        estimatedRepair: 18000,
        investmentScore: 6.5,
        status: 'new',
        notes: 'Needs kitchen and bathroom updates',
        userId: user.id,
      },
    }),
    prisma.property.create({
      data: {
        address: '321 Elm Drive',
        city: 'San Antonio',
        state: 'TX',
        zipCode: '78201',
        propertyType: 'Townhouse',
        bedrooms: 3,
        bathrooms: 2,
        squareFeet: 1650,
        yearBuilt: 1992,
        lotSize: 0.12,
        arv: 198000,
        estimatedRepair: 22000,
        investmentScore: 7.1,
        status: 'under_contract',
        notes: 'End unit townhouse, good condition',
        userId: user.id,
      },
    }),
    prisma.property.create({
      data: {
        address: '654 Maple Lane',
        city: 'Dallas',
        state: 'TX',
        zipCode: '75202',
        propertyType: 'Single Family',
        bedrooms: 4,
        bathrooms: 2,
        squareFeet: 2100,
        yearBuilt: 1985,
        lotSize: 0.28,
        arv: 275000,
        estimatedRepair: 15000,
        investmentScore: 8.5,
        status: 'closed',
        notes: 'Recently closed deal, minimal repairs needed',
        userId: user.id,
      },
    }),
  ])

  console.log('✅ Created properties')

  // Create leads for properties
  const leads = await Promise.all([
    prisma.lead.create({
      data: {
        propertyId: properties[0].id,
        sellerName: 'John Smith',
        sellerPhone: '(555) 123-4567',
        sellerEmail: 'john.smith@email.com',
        motivation: 'Job relocation',
        timeline: '30-60 days',
        stage: 'contacted',
        priority: 'high',
        source: 'Direct Mail',
        notes: 'Very motivated seller, relocating for work',
        lastContact: new Date('2024-01-18'),
        nextFollowUp: new Date('2024-01-25'),
        userId: user.id,
      },
    }),
    prisma.lead.create({
      data: {
        propertyId: properties[1].id,
        sellerName: 'Sarah Johnson',
        sellerPhone: '(555) 234-5678',
        sellerEmail: 'sarah.johnson@email.com',
        motivation: 'Financial hardship',
        timeline: '60-90 days',
        stage: 'negotiating',
        priority: 'medium',
        source: 'Online Marketing',
        notes: 'Needs time to find new place',
        lastContact: new Date('2024-01-15'),
        nextFollowUp: new Date('2024-01-22'),
        userId: user.id,
      },
    }),
    prisma.lead.create({
      data: {
        propertyId: properties[2].id,
        sellerName: 'Mike Wilson',
        sellerPhone: '(555) 345-6789',
        sellerEmail: 'mike.wilson@email.com',
        motivation: 'Inherited property',
        timeline: 'ASAP',
        stage: 'new',
        priority: 'high',
        source: 'Referral',
        notes: 'Inherited from grandmother, wants quick sale',
        lastContact: null,
        nextFollowUp: new Date('2024-01-21'),
        userId: user.id,
      },
    }),
    prisma.lead.create({
      data: {
        propertyId: properties[3].id,
        sellerName: 'Lisa Brown',
        sellerPhone: '(555) 456-7890',
        sellerEmail: 'lisa.brown@email.com',
        motivation: 'Downsizing',
        timeline: '90+ days',
        stage: 'under_contract',
        priority: 'medium',
        source: 'Cold Calling',
        notes: 'Empty nesters looking to downsize',
        lastContact: new Date('2024-01-10'),
        nextFollowUp: null,
        userId: user.id,
      },
    }),
    prisma.lead.create({
      data: {
        propertyId: properties[4].id,
        sellerName: 'Tom Davis',
        sellerPhone: '(555) 567-8901',
        sellerEmail: 'tom.davis@email.com',
        motivation: 'Investment liquidation',
        timeline: '30 days',
        stage: 'closed',
        priority: 'low',
        source: 'Direct Mail',
        notes: 'Liquidating rental portfolio',
        lastContact: new Date('2024-01-05'),
        nextFollowUp: null,
        userId: user.id,
      },
    }),
  ])

  console.log('✅ Created leads')

  // Create SMS campaigns
  const smsCampaigns = await Promise.all([
    prisma.smsCampaign.create({
      data: {
        name: 'Distressed Property Outreach',
        template: 'Hi {name}, I saw your property at {address}. Are you still looking to sell? I can make a cash offer. Reply YES for more info.',
        status: 'active',
        totalSent: 245,
        delivered: 238,
        responses: 44,
      },
    }),
    prisma.smsCampaign.create({
      data: {
        name: 'Follow-up Sequence',
        template: 'Hi {name}, following up on my previous message about {address}. Would you like to discuss a cash offer?',
        status: 'paused',
        totalSent: 156,
        delivered: 152,
        responses: 23,
      },
    }),
    prisma.smsCampaign.create({
      data: {
        name: 'New Lead Welcome',
        template: 'Thank you for your interest in selling {address}. When would be a good time for a quick 5-minute call?',
        status: 'draft',
        totalSent: 0,
        delivered: 0,
        responses: 0,
      },
    }),
    prisma.smsCampaign.create({
      data: {
        name: 'Motivated Seller Campaign',
        template: 'Hi {name}, I buy houses fast for cash in {city}. No repairs needed. Interested in a quick sale of {address}?',
        status: 'completed',
        totalSent: 387,
        delivered: 381,
        responses: 72,
      },
    }),
  ])

  console.log('✅ Created SMS campaigns')

  // Create email campaigns
  const emailCampaigns = await Promise.all([
    prisma.emailCampaign.create({
      data: {
        name: 'New Property Alert - Dallas',
        subject: 'New Investment Opportunity in Dallas',
        template: 'Hi {buyer_name}, we have a new property in Dallas that matches your investment criteria...',
        type: 'buyer_outreach',
        status: 'active',
        totalSent: 156,
        delivered: 152,
        opened: 38,
        clicked: 12,
        userId: user.id,
      },
    }),
    prisma.emailCampaign.create({
      data: {
        name: 'Weekly Property Digest',
        subject: 'This Week\'s Top Investment Properties',
        template: 'Here are the best investment opportunities from this week...',
        type: 'buyer_outreach',
        status: 'scheduled',
        totalSent: 0,
        delivered: 0,
        opened: 0,
        clicked: 0,
        scheduledAt: new Date('2024-01-22T09:00:00Z'),
        userId: user.id,
      },
    }),
    prisma.emailCampaign.create({
      data: {
        name: 'Seller Follow-up Sequence',
        subject: 'Following up on your property inquiry',
        template: 'Hi {seller_name}, I wanted to follow up on our conversation about your property...',
        type: 'seller_followup',
        status: 'paused',
        totalSent: 87,
        delivered: 85,
        opened: 21,
        clicked: 5,
        userId: user.id,
      },
    }),
    prisma.emailCampaign.create({
      data: {
        name: 'Investment Opportunity',
        subject: 'Exclusive Off-Market Deal',
        template: 'We have an exclusive off-market property that fits your investment criteria...',
        type: 'buyer_outreach',
        status: 'completed',
        totalSent: 243,
        delivered: 238,
        opened: 59,
        clicked: 18,
        userId: user.id,
      },
    }),
  ])

  console.log('✅ Created email campaigns')

  // Create contracts
  const contracts = await Promise.all([
    prisma.contract.create({
      data: {
        propertyId: properties[0].id,
        leadId: leads[0].id,
        buyerId: buyers[0].id,
        type: 'purchase',
        purchasePrice: 185000,
        assignmentFee: 8000,
        status: 'signed',
        contractDate: new Date('2024-01-15'),
        closingDate: new Date('2024-02-15'),
        state: 'TX',
        template: 'Texas Purchase Agreement',
        notes: 'Standard purchase with 30-day closing',
        userId: user.id,
      },
    }),
    prisma.contract.create({
      data: {
        propertyId: properties[1].id,
        leadId: leads[1].id,
        buyerId: buyers[1].id,
        type: 'assignment',
        purchasePrice: 225000,
        assignmentFee: 12000,
        status: 'pending',
        contractDate: new Date('2024-01-18'),
        closingDate: new Date('2024-02-20'),
        state: 'TX',
        template: 'Texas Assignment Contract',
        notes: 'Assignment contract pending buyer signature',
        userId: user.id,
      },
    }),
    prisma.contract.create({
      data: {
        propertyId: properties[2].id,
        leadId: leads[2].id,
        buyerId: buyers[2].id,
        type: 'purchase',
        purchasePrice: 165000,
        assignmentFee: 6500,
        status: 'draft',
        contractDate: new Date('2024-01-20'),
        closingDate: new Date('2024-02-25'),
        state: 'TX',
        template: 'Texas Purchase Agreement',
        notes: 'Draft contract being reviewed',
        userId: user.id,
      },
    }),
    prisma.contract.create({
      data: {
        propertyId: properties[4].id,
        leadId: leads[4].id,
        buyerId: buyers[3].id,
        type: 'assignment',
        purchasePrice: 142000,
        assignmentFee: 5500,
        status: 'completed',
        contractDate: new Date('2024-01-05'),
        closingDate: new Date('2024-01-28'),
        state: 'TX',
        template: 'Texas Assignment Contract',
        notes: 'Successfully completed assignment',
        userId: user.id,
      },
    }),
  ])

  console.log('✅ Created contracts')

  // Create SMS messages
  await Promise.all([
    prisma.smsMessage.create({
      data: {
        leadId: leads[0].id,
        userId: user.id,
        phoneNumber: '(555) 123-4567',
        message: 'Hi John, I saw your property at 123 Main Street. Are you still looking to sell?',
        direction: 'outbound',
        status: 'delivered',
        campaignId: smsCampaigns[0].id,
        sentAt: new Date('2024-01-18T10:00:00Z'),
      },
    }),
    prisma.smsMessage.create({
      data: {
        leadId: leads[0].id,
        userId: user.id,
        phoneNumber: '(555) 123-4567',
        message: 'Yes, I am interested in selling. Can you call me?',
        direction: 'inbound',
        status: 'received',
        sentAt: new Date('2024-01-18T10:15:00Z'),
      },
    }),
    prisma.smsMessage.create({
      data: {
        leadId: leads[1].id,
        userId: user.id,
        phoneNumber: '(555) 234-5678',
        message: 'Hi Sarah, following up on our conversation about 456 Oak Avenue.',
        direction: 'outbound',
        status: 'delivered',
        campaignId: smsCampaigns[1].id,
        sentAt: new Date('2024-01-15T14:30:00Z'),
      },
    }),
  ])

  console.log('✅ Created SMS messages')

  // Create email messages
  await Promise.all([
    prisma.emailMessage.create({
      data: {
        buyerId: buyers[0].id,
        subject: 'New Property Alert - Dallas Investment Opportunity',
        content: 'Hi Smith Investment Group, we have a new property in Dallas...',
        recipient: 'contact@smithinvestments.com',
        status: 'delivered',
        campaignId: emailCampaigns[0].id,
        sentAt: new Date('2024-01-17T09:00:00Z'),
      },
    }),
    prisma.emailMessage.create({
      data: {
        buyerId: buyers[1].id,
        subject: 'This Week\'s Top Investment Properties',
        content: 'Here are the best investment opportunities from this week...',
        recipient: 'deals@houstonprops.com',
        status: 'opened',
        campaignId: emailCampaigns[1].id,
        sentAt: new Date('2024-01-15T08:00:00Z'),
      },
    }),
  ])

  console.log('✅ Created email messages')

  // Create activities
  await Promise.all([
    prisma.activity.create({
      data: {
        type: 'sms_sent',
        description: 'SMS sent to seller at 123 Main Street',
        propertyId: properties[0].id,
        leadId: leads[0].id,
        userId: user.id,
        metadata: { campaign: 'Distressed Property Outreach' },
      },
    }),
    prisma.activity.create({
      data: {
        type: 'property_analyzed',
        description: 'Property analyzed: 456 Oak Avenue - Score: 8.2',
        propertyId: properties[1].id,
        userId: user.id,
        metadata: { score: 8.2, arv: 320000 },
      },
    }),
    prisma.activity.create({
      data: {
        type: 'email_sent',
        description: 'Email campaign sent to 24 buyers',
        userId: user.id,
        metadata: { campaign: 'New Property Alert', recipients: 24 },
      },
    }),
    prisma.activity.create({
      data: {
        type: 'contract_created',
        description: 'Contract generated for 789 Pine Street',
        propertyId: properties[2].id,
        userId: user.id,
        metadata: { contractType: 'purchase', value: 165000 },
      },
    }),
  ])

  console.log('✅ Created activities')

  // Create system settings
  await Promise.all([
    prisma.systemSettings.create({
      data: {
        key: 'auto_opt_out',
        value: 'true',
        category: 'sms',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'consent_tracking',
        value: 'true',
        category: 'sms',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'call_time_restrictions',
        value: 'true',
        category: 'sms',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'dnc_integration',
        value: 'true',
        category: 'sms',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'company_name',
        value: 'RESYSUM Real Estate',
        category: 'general',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'business_phone',
        value: '(555) 123-4567',
        category: 'general',
      },
    }),
    prisma.systemSettings.create({
      data: {
        key: 'timezone',
        value: 'America/Chicago',
        category: 'general',
      },
    }),
  ])

  console.log('✅ Created system settings')
  console.log('🎉 Database seeding completed successfully!')
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
