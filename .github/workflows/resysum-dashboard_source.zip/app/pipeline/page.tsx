
import { PipelineBoard } from '@/components/pipeline/pipeline-board'

export default function PipelinePage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Lead Pipeline</h1>
        <p className="text-gray-600">Track your deals through the sales process</p>
      </div>
      
      <PipelineBoard />
    </div>
  )
}
