
import { SettingsNavigation } from '@/components/settings/settings-navigation'
import { GeneralSettings } from '@/components/settings/general-settings'
import { ComplianceSettings } from '@/components/settings/compliance-settings'
import { IntegrationSettings } from '@/components/settings/integration-settings'
import { NotificationSettings } from '@/components/settings/notification-settings'

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600">Configure your RESYSUM system</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <SettingsNavigation />
        </div>
        <div className="lg:col-span-3 space-y-6">
          <GeneralSettings />
          <ComplianceSettings />
          <IntegrationSettings />
          <NotificationSettings />
        </div>
      </div>
    </div>
  )
}
