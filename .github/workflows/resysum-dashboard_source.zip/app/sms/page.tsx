
import { SmsHeader } from '@/components/sms/sms-header'
import { SmsCampaigns } from '@/components/sms/sms-campaigns'
import { SmsTemplates } from '@/components/sms/sms-templates'

export default function SmsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">SMS Campaigns</h1>
        <p className="text-gray-600">Manage your SMS outreach campaigns</p>
      </div>
      
      <SmsHeader />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SmsCampaigns />
        </div>
        <div>
          <SmsTemplates />
        </div>
      </div>
    </div>
  )
}
