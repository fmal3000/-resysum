
import { ContractsHeader } from '@/components/contracts/contracts-header'
import { ContractsTable } from '@/components/contracts/contracts-table'
import { ContractTemplates } from '@/components/contracts/contract-templates'

export default function ContractsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Contracts</h1>
        <p className="text-gray-600">Manage contracts and assignments</p>
      </div>
      
      <ContractsHeader />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ContractsTable />
        </div>
        <div>
          <ContractTemplates />
        </div>
      </div>
    </div>
  )
}
