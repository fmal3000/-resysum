
import { AnalyticsHeader } from '@/components/analytics/analytics-header'
import { PerformanceCharts } from '@/components/analytics/performance-charts'
import { ConversionFunnel } from '@/components/analytics/conversion-funnel'
import { CampaignMetrics } from '@/components/analytics/campaign-metrics'

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Analytics & Reports</h1>
        <p className="text-gray-600">Track performance and generate insights</p>
      </div>
      
      <AnalyticsHeader />
      <PerformanceCharts />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ConversionFunnel />
        <CampaignMetrics />
      </div>
    </div>
  )
}
