
import { EmailHeader } from '@/components/email/email-header'
import { EmailCampaigns } from '@/components/email/email-campaigns'
import { EmailTemplates } from '@/components/email/email-templates'

export default function EmailPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Email Marketing</h1>
        <p className="text-gray-600">Manage buyer outreach and email campaigns</p>
      </div>
      
      <EmailHeader />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <EmailCampaigns />
        </div>
        <div>
          <EmailTemplates />
        </div>
      </div>
    </div>
  )
}
