
import { PropertiesHeader } from '@/components/properties/properties-header'
import { PropertiesTable } from '@/components/properties/properties-table'

export default function PropertiesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Properties</h1>
        <p className="text-gray-600">Manage and analyze your property portfolio</p>
      </div>
      
      <PropertiesHeader />
      <PropertiesTable />
    </div>
  )
}
