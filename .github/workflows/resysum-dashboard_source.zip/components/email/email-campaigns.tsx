
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Play, Pause, Edit, Trash2, BarChart3, Calendar } from 'lucide-react'

const campaigns = [
  {
    id: 1,
    name: 'New Property Alert - Dallas',
    type: 'buyer_outreach',
    status: 'active',
    totalSent: 156,
    delivered: 152,
    opened: 38,
    clicked: 12,
    openRate: 25.0,
    clickRate: 7.9,
    scheduledAt: null,
    createdAt: '2024-01-15',
  },
  {
    id: 2,
    name: 'Weekly Property Digest',
    type: 'buyer_outreach',
    status: 'scheduled',
    totalSent: 0,
    delivered: 0,
    opened: 0,
    clicked: 0,
    openRate: 0,
    clickRate: 0,
    scheduledAt: '2024-01-22T09:00:00Z',
    createdAt: '2024-01-18',
  },
  {
    id: 3,
    name: 'Seller Follow-up Sequence',
    type: 'seller_followup',
    status: 'paused',
    totalSent: 87,
    delivered: 85,
    opened: 21,
    clicked: 5,
    openRate: 24.7,
    clickRate: 5.9,
    scheduledAt: null,
    createdAt: '2024-01-12',
  },
  {
    id: 4,
    name: 'Investment Opportunity',
    type: 'buyer_outreach',
    status: 'completed',
    totalSent: 243,
    delivered: 238,
    opened: 59,
    clicked: 18,
    openRate: 24.8,
    clickRate: 7.6,
    scheduledAt: null,
    createdAt: '2024-01-08',
  },
]

const statusColors = {
  active: 'bg-green-100 text-green-800',
  paused: 'bg-yellow-100 text-yellow-800',
  scheduled: 'bg-blue-100 text-blue-800',
  completed: 'bg-gray-100 text-gray-800',
  draft: 'bg-purple-100 text-purple-800',
}

const typeColors = {
  buyer_outreach: 'bg-blue-100 text-blue-800',
  seller_followup: 'bg-green-100 text-green-800',
}

export function EmailCampaigns() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Email Campaigns
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campaign</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent</TableHead>
                <TableHead>Open Rate</TableHead>
                <TableHead>Click Rate</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {campaigns?.map((campaign) => (
                <TableRow key={campaign.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium text-gray-900">{campaign.name}</div>
                      <div className="text-sm text-gray-500">
                        {campaign.scheduledAt ? (
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span>Scheduled for {new Date(campaign.scheduledAt).toLocaleDateString()}</span>
                          </div>
                        ) : (
                          `Created ${new Date(campaign.createdAt).toLocaleDateString()}`
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={typeColors[campaign.type as keyof typeof typeColors]}
                    >
                      {campaign.type.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={statusColors[campaign.status as keyof typeof statusColors]}
                    >
                      {campaign.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{campaign.totalSent}</TableCell>
                  <TableCell className="text-sm font-medium">
                    {campaign.openRate}%
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    {campaign.clickRate}%
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {campaign.status === 'active' ? (
                        <Button variant="ghost" size="sm">
                          <Pause className="h-4 w-4" />
                        </Button>
                      ) : campaign.status === 'paused' ? (
                        <Button variant="ghost" size="sm">
                          <Play className="h-4 w-4" />
                        </Button>
                      ) : null}
                      <Button variant="ghost" size="sm">
                        <BarChart3 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
