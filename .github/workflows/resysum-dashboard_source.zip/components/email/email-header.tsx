
'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Mail, Users, MousePointer, TrendingUp } from 'lucide-react'

const stats = [
  {
    title: 'Emails Sent',
    value: '2,847',
    icon: Mail,
    color: 'text-blue-600',
    bgColor: 'bg-blue-100',
  },
  {
    title: 'Open Rate',
    value: '24.8%',
    icon: TrendingUp,
    color: 'text-green-600',
    bgColor: 'bg-green-100',
  },
  {
    title: 'Click Rate',
    value: '6.2%',
    icon: MousePointer,
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
  },
  {
    title: 'Active Buyers',
    value: '156',
    icon: Users,
    color: 'text-orange-600',
    bgColor: 'bg-orange-100',
  },
]

export function EmailHeader() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Email Campaign Overview</h2>
          <p className="text-sm text-gray-600">Track your email marketing performance and buyer engagement</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Mail className="h-4 w-4 mr-2" />
          Create Campaign
        </Button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats?.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{stat.title}</p>
                    <p className="text-xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
