
'use client'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Eye, Edit, Trash2 } from 'lucide-react'

const properties = [
  {
    id: 1,
    address: '123 Main Street',
    city: 'Dallas',
    state: 'TX',
    zipCode: '75201',
    propertyType: 'Single Family',
    bedrooms: 3,
    bathrooms: 2.5,
    squareFeet: 1850,
    arv: 285000,
    estimatedRepair: 35000,
    investmentScore: 8.2,
    status: 'analyzed',
  },
  {
    id: 2,
    address: '456 Oak Avenue',
    city: 'Houston',
    state: 'TX',
    zipCode: '77001',
    propertyType: 'Duplex',
    bedrooms: 4,
    bathrooms: 3,
    squareFeet: 2200,
    arv: 320000,
    estimatedRepair: 28000,
    investmentScore: 7.8,
    status: 'contacted',
  },
  {
    id: 3,
    address: '789 Pine Street',
    city: 'Austin',
    state: 'TX',
    zipCode: '78701',
    propertyType: 'Single Family',
    bedrooms: 2,
    bathrooms: 1,
    squareFeet: 1200,
    arv: 245000,
    estimatedRepair: 18000,
    investmentScore: 6.5,
    status: 'new',
  },
  {
    id: 4,
    address: '321 Elm Drive',
    city: 'San Antonio',
    state: 'TX',
    zipCode: '78201',
    propertyType: 'Townhouse',
    bedrooms: 3,
    bathrooms: 2,
    squareFeet: 1650,
    arv: 198000,
    estimatedRepair: 22000,
    investmentScore: 7.1,
    status: 'under_contract',
  },
]

const statusColors = {
  new: 'bg-gray-100 text-gray-800',
  analyzing: 'bg-blue-100 text-blue-800',
  analyzed: 'bg-green-100 text-green-800',
  contacted: 'bg-yellow-100 text-yellow-800',
  contracted: 'bg-purple-100 text-purple-800',
  closed: 'bg-emerald-100 text-emerald-800',
  under_contract: 'bg-orange-100 text-orange-800',
}

function getScoreColor(score: number) {
  if (score >= 8) return 'text-green-600 font-semibold'
  if (score >= 6) return 'text-yellow-600 font-semibold'
  return 'text-red-600 font-semibold'
}

export function PropertiesTable() {
  return (
    <Card>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Property</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Bed/Bath</TableHead>
                <TableHead>Sq Ft</TableHead>
                <TableHead>ARV</TableHead>
                <TableHead>Repairs</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {properties?.map((property) => (
                <TableRow key={property.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium text-gray-900">{property.address}</div>
                      <div className="text-sm text-gray-500">
                        {property.city}, {property.state} {property.zipCode}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{property.propertyType}</TableCell>
                  <TableCell className="text-sm">
                    {property.bedrooms}bd / {property.bathrooms}ba
                  </TableCell>
                  <TableCell className="text-sm">
                    {property.squareFeet?.toLocaleString()} sq ft
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    ${property.arv?.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-sm">
                    ${property.estimatedRepair?.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <span className={`text-sm ${getScoreColor(property.investmentScore)}`}>
                      {property.investmentScore}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={statusColors[property.status as keyof typeof statusColors]}
                    >
                      {property.status.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
