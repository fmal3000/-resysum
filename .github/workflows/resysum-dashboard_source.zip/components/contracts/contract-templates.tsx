
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Copy, Edit, Plus, Download } from 'lucide-react'

const templates = [
  {
    id: 1,
    name: 'Texas Purchase Agreement',
    state: 'TX',
    type: 'purchase',
    description: 'Standard purchase agreement for Texas properties',
    usageCount: 24,
    lastUsed: '2024-01-18',
  },
  {
    id: 2,
    name: 'Texas Assignment Contract',
    state: 'TX',
    type: 'assignment',
    description: 'Assignment of purchase agreement for Texas',
    usageCount: 18,
    lastUsed: '2024-01-15',
  },
  {
    id: 3,
    name: 'Florida Purchase Agreement',
    state: 'FL',
    type: 'purchase',
    description: 'Standard purchase agreement for Florida properties',
    usageCount: 12,
    lastUsed: '2024-01-12',
  },
  {
    id: 4,
    name: 'Earnest Money Agreement',
    state: 'All',
    type: 'other',
    description: 'Earnest money deposit agreement',
    usageCount: 8,
    lastUsed: '2024-01-10',
  },
]

const typeColors = {
  purchase: 'bg-blue-100 text-blue-800',
  assignment: 'bg-purple-100 text-purple-800',
  other: 'bg-gray-100 text-gray-800',
}

export function ContractTemplates() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">
            Contract Templates
          </CardTitle>
          <Button size="sm" variant="outline">
            <Plus className="h-4 w-4 mr-2" />
            New
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {templates?.map((template) => (
          <div key={template.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h4 className="font-medium text-sm text-gray-900">{template.name}</h4>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="outline" className="text-xs">
                    {template.state}
                  </Badge>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${typeColors[template.type as keyof typeof typeColors]}`}
                  >
                    {template.type}
                  </Badge>
                </div>
              </div>
              <div className="flex space-x-1">
                <Button variant="ghost" size="sm">
                  <Copy className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Download className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Edit className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-600 mb-2">
              {template.description}
            </p>
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>Used {template.usageCount} times</span>
              <span>Last used {new Date(template.lastUsed).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
