
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Download, Edit, Eye, Send } from 'lucide-react'

const contracts = [
  {
    id: 1,
    propertyAddress: '123 Main Street, Dallas, TX',
    type: 'purchase',
    purchasePrice: 185000,
    assignmentFee: 8000,
    status: 'signed',
    contractDate: '2024-01-15',
    closingDate: '2024-02-15',
    buyerName: 'Smith Investment Group',
    state: 'TX',
  },
  {
    id: 2,
    propertyAddress: '456 Oak Avenue, Houston, TX',
    type: 'assignment',
    purchasePrice: 225000,
    assignmentFee: 12000,
    status: 'pending',
    contractDate: '2024-01-18',
    closingDate: '2024-02-20',
    buyerName: 'Houston Properties LLC',
    state: 'TX',
  },
  {
    id: 3,
    propertyAddress: '789 Pine Street, Austin, TX',
    type: 'purchase',
    purchasePrice: 165000,
    assignmentFee: 6500,
    status: 'draft',
    contractDate: '2024-01-20',
    closingDate: '2024-02-25',
    buyerName: 'Austin Investors',
    state: 'TX',
  },
  {
    id: 4,
    propertyAddress: '321 Elm Drive, San Antonio, TX',
    type: 'assignment',
    purchasePrice: 142000,
    assignmentFee: 5500,
    status: 'completed',
    contractDate: '2024-01-05',
    closingDate: '2024-01-28',
    buyerName: 'Alamo Real Estate',
    state: 'TX',
  },
]

const statusColors = {
  draft: 'bg-gray-100 text-gray-800',
  pending: 'bg-yellow-100 text-yellow-800',
  signed: 'bg-blue-100 text-blue-800',
  completed: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
}

const typeColors = {
  purchase: 'bg-blue-100 text-blue-800',
  assignment: 'bg-purple-100 text-purple-800',
}

export function ContractsTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Contracts & Assignments
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Property</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Purchase Price</TableHead>
                <TableHead>Assignment Fee</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Closing Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts?.map((contract) => (
                <TableRow key={contract.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium text-gray-900 text-sm">
                        {contract.propertyAddress}
                      </div>
                      <div className="text-xs text-gray-500">
                        Buyer: {contract.buyerName}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={typeColors[contract.type as keyof typeof typeColors]}
                    >
                      {contract.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    ${contract.purchasePrice?.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-sm font-medium text-green-600">
                    ${contract.assignmentFee?.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={statusColors[contract.status as keyof typeof statusColors]}
                    >
                      {contract.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">
                    {new Date(contract.closingDate).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      {contract.status === 'draft' && (
                        <Button variant="ghost" size="sm">
                          <Send className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
