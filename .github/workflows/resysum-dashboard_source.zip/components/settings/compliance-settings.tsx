
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'

export function ComplianceSettings() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          TCPA Compliance Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label>Auto Opt-out Processing</Label>
            <p className="text-sm text-gray-600">
              Automatically process STOP keywords and opt-out requests
            </p>
          </div>
          <Switch defaultChecked />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label>Consent Tracking</Label>
            <p className="text-sm text-gray-600">
              Track and store consent records for all communications
            </p>
          </div>
          <Switch defaultChecked />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label>Call Time Restrictions</Label>
            <p className="text-sm text-gray-600">
              Enforce calling hours based on recipient time zone
            </p>
          </div>
          <Switch defaultChecked />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <Label>DNC List Integration</Label>
            <p className="text-sm text-gray-600">
              Check against Do Not Call registries before outreach
            </p>
          </div>
          <Switch defaultChecked />
        </div>
        
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-green-900">Compliance Status</h4>
              <p className="text-sm text-green-700">All systems are compliant</p>
            </div>
            <Badge className="bg-green-100 text-green-800">98% Score</Badge>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button className="bg-blue-600 hover:bg-blue-700">
            Save Compliance Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
