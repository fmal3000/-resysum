
'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Settings, Shield, Zap, Bell } from 'lucide-react'

const settingsSections = [
  { id: 'general', name: 'General', icon: Settings },
  { id: 'compliance', name: 'Compliance', icon: Shield },
  { id: 'integrations', name: 'Integrations', icon: Zap },
  { id: 'notifications', name: 'Notifications', icon: Bell },
]

export function SettingsNavigation() {
  return (
    <Card>
      <CardContent className="p-4">
        <nav className="space-y-2">
          {settingsSections?.map((section) => {
            const Icon = section.icon
            return (
              <Button
                key={section.id}
                variant="ghost"
                className="w-full justify-start"
              >
                <Icon className="h-4 w-4 mr-2" />
                {section.name}
              </Button>
            )
          })}
        </nav>
      </CardContent>
    </Card>
  )
}
