
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'

export function NotificationSettings() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Notification Preferences
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Email Notifications</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>New Lead Notifications</Label>
                <p className="text-sm text-gray-600">Get notified when new leads are added</p>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Deal Status Updates</Label>
                <p className="text-sm text-gray-600">Notifications for deal stage changes</p>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Campaign Reports</Label>
                <p className="text-sm text-gray-600">Weekly campaign performance summaries</p>
              </div>
              <Switch />
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-medium text-gray-900 mb-4">SMS Notifications</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Urgent Lead Responses</Label>
                <p className="text-sm text-gray-600">SMS alerts for high-priority responses</p>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Contract Reminders</Label>
                <p className="text-sm text-gray-600">Reminders for contract deadlines</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button className="bg-blue-600 hover:bg-blue-700">
            Save Notification Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
