
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'

const integrations = [
  {
    name: 'Twilio SMS',
    description: 'SMS messaging service',
    status: 'connected',
    lastSync: '2 minutes ago',
  },
  {
    name: 'SendGrid Email',
    description: 'Email delivery service',
    status: 'connected',
    lastSync: '5 minutes ago',
  },
  {
    name: 'Zillow API',
    description: 'Property data integration',
    status: 'disconnected',
    lastSync: 'Never',
  },
  {
    name: 'DocuSign',
    description: 'Digital signature service',
    status: 'connected',
    lastSync: '1 hour ago',
  },
]

export function IntegrationSettings() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Integrations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {integrations?.map((integration) => (
          <div key={integration.name} className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium text-gray-900">{integration.name}</h4>
              <p className="text-sm text-gray-600">{integration.description}</p>
              <p className="text-xs text-gray-500 mt-1">Last sync: {integration.lastSync}</p>
            </div>
            <div className="flex items-center space-x-3">
              <Badge 
                variant="outline"
                className={
                  integration.status === 'connected' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }
              >
                {integration.status}
              </Badge>
              <Button variant="outline" size="sm">
                {integration.status === 'connected' ? 'Configure' : 'Connect'}
              </Button>
            </div>
          </div>
        ))}
        
        <div className="space-y-4 pt-4 border-t">
          <h4 className="font-medium text-gray-900">API Configuration</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="twilio-sid">Twilio Account SID</Label>
              <Input id="twilio-sid" type="password" defaultValue="••••••••••••••••" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="twilio-token">Twilio Auth Token</Label>
              <Input id="twilio-token" type="password" defaultValue="••••••••••••••••" />
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Save API Settings
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
