
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const revenueData = [
  { month: 'Jan', revenue: 45000, deals: 8 },
  { month: 'Feb', revenue: 52000, deals: 10 },
  { month: 'Mar', revenue: 48000, deals: 9 },
  { month: 'Apr', revenue: 61000, deals: 12 },
  { month: 'May', revenue: 55000, deals: 11 },
  { month: 'Jun', revenue: 67000, deals: 14 },
]

const dealCycleData = [
  { stage: 'Lead Gen', avgDays: 2 },
  { stage: 'Initial Contact', avgDays: 5 },
  { stage: 'Negotiation', avgDays: 8 },
  { stage: 'Contract', avgDays: 12 },
  { stage: 'Closing', avgDays: 25 },
]

const leadSourceData = [
  { source: 'Direct Mail', leads: 156, cost: 4200 },
  { source: 'Online Marketing', leads: 89, cost: 2800 },
  { source: 'Referrals', leads: 67, cost: 0 },
  { source: 'Cold Calling', leads: 45, cost: 1500 },
  { source: 'Networking', leads: 23, cost: 800 },
]

export function PerformanceCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Revenue Over Time */}
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Revenue by Month
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="month" 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
                tickFormatter={(value) => `$${value/1000}k`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: 11
                }}
                formatter={(value: any) => [`$${value?.toLocaleString()}`, 'Revenue']}
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#10B981"
                strokeWidth={2}
                fill="url(#colorRevenue)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Average Deal Cycle */}
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Average Deal Cycle Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dealCycleData} layout="horizontal">
              <XAxis 
                type="number"
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                type="category"
                dataKey="stage"
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
                width={80}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: 11
                }}
                formatter={(value: any) => [`${value} days`, 'Average Time']}
              />
              <Bar 
                dataKey="avgDays" 
                fill="#60B5FF"
                radius={[0, 4, 4, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Lead Source Performance */}
      <Card className="hover:shadow-lg transition-shadow duration-300 lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Lead Source Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={leadSourceData}>
              <XAxis 
                dataKey="source" 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                yAxisId="left"
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                yAxisId="right"
                orientation="right"
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: 11
                }}
              />
              <Bar yAxisId="left" dataKey="leads" fill="#60B5FF" name="Leads" />
              <Bar yAxisId="right" dataKey="cost" fill="#FF9149" name="Cost ($)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}
