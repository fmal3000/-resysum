
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const funnelData = [
  { stage: 'Total Leads', count: 1247, percentage: 100, color: 'bg-blue-500' },
  { stage: 'Contacted', count: 892, percentage: 71.5, color: 'bg-blue-400' },
  { stage: 'Interested', count: 534, percentage: 42.8, color: 'bg-blue-300' },
  { stage: 'Under Contract', count: 156, percentage: 12.5, color: 'bg-blue-200' },
  { stage: 'Closed', count: 89, percentage: 7.1, color: 'bg-blue-100' },
]

export function ConversionFunnel() {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Lead Conversion Funnel
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {funnelData?.map((item, index) => (
            <div key={item.stage} className="flex items-center space-x-4">
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-900">{item.stage}</span>
                  <span className="text-sm text-gray-600">{item.count}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${item.color}`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-xs text-gray-500">{item.percentage}%</span>
                  {index > 0 && (
                    <span className="text-xs text-red-500">
                      -{(funnelData[index-1].percentage - item.percentage).toFixed(1)}%
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
