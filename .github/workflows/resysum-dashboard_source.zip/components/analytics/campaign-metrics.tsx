
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, TrendingDown, MessageSquare, Mail } from 'lucide-react'

const campaigns = [
  {
    id: 1,
    name: 'Distressed Property SMS',
    type: 'sms',
    sent: 245,
    responses: 44,
    responseRate: 18.0,
    trend: 'up',
    trendValue: 2.3,
  },
  {
    id: 2,
    name: 'Weekly Property Digest',
    type: 'email',
    sent: 156,
    responses: 38,
    responseRate: 24.4,
    trend: 'up',
    trendValue: 1.8,
  },
  {
    id: 3,
    name: 'Follow-up Sequence',
    type: 'sms',
    sent: 187,
    responses: 23,
    responseRate: 12.3,
    trend: 'down',
    trendValue: 3.2,
  },
  {
    id: 4,
    name: 'New Property Alert',
    type: 'email',
    sent: 289,
    responses: 71,
    responseRate: 24.6,
    trend: 'up',
    trendValue: 0.9,
  },
]

export function CampaignMetrics() {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Campaign Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {campaigns?.map((campaign) => (
            <div key={campaign.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {campaign.type === 'sms' ? (
                    <MessageSquare className="h-4 w-4 text-blue-600" />
                  ) : (
                    <Mail className="h-4 w-4 text-purple-600" />
                  )}
                  <h4 className="font-medium text-sm text-gray-900">{campaign.name}</h4>
                </div>
                <Badge variant="outline" className={
                  campaign.type === 'sms' 
                    ? 'bg-blue-100 text-blue-800' 
                    : 'bg-purple-100 text-purple-800'
                }>
                  {campaign.type.toUpperCase()}
                </Badge>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Sent</p>
                  <p className="font-medium">{campaign.sent}</p>
                </div>
                <div>
                  <p className="text-gray-600">Responses</p>
                  <p className="font-medium">{campaign.responses}</p>
                </div>
                <div>
                  <p className="text-gray-600">Rate</p>
                  <div className="flex items-center space-x-1">
                    <p className="font-medium">{campaign.responseRate}%</p>
                    {campaign.trend === 'up' ? (
                      <div className="flex items-center text-green-600">
                        <TrendingUp className="h-3 w-3" />
                        <span className="text-xs">+{campaign.trendValue}%</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-red-600">
                        <TrendingDown className="h-3 w-3" />
                        <span className="text-xs">-{campaign.trendValue}%</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
