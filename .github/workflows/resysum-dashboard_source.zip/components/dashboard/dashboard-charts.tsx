
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const dealVelocityData = [
  { month: 'Jan', deals: 12 },
  { month: 'Feb', deals: 18 },
  { month: 'Mar', deals: 15 },
  { month: 'Apr', deals: 24 },
  { month: 'May', deals: 28 },
  { month: 'Jun', deals: 32 },
]

const leadSourceData = [
  { name: 'Direct Mail', value: 35, color: '#60B5FF' },
  { name: 'Online Marketing', value: 28, color: '#FF9149' },
  { name: 'Referrals', value: 20, color: '#FF9898' },
  { name: 'Cold Calling', value: 12, color: '#80D8C3' },
  { name: 'Other', value: 5, color: '#A19AD3' },
]

export function DashboardCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Deal Velocity Chart */}
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Deal Velocity Over Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={dealVelocityData}>
              <defs>
                <linearGradient id="colorDeals" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#60B5FF" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#60B5FF" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="month" 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <YAxis 
                tickLine={false}
                tick={{ fontSize: 10 }}
                axisLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: 11
                }}
              />
              <Area
                type="monotone"
                dataKey="deals"
                stroke="#60B5FF"
                strokeWidth={2}
                fill="url(#colorDeals)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Lead Source Breakdown */}
      <Card className="hover:shadow-lg transition-shadow duration-300">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Lead Source Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <ResponsiveContainer width={200} height={200}>
              <PieChart>
                <Pie
                  data={leadSourceData}
                  cx={100}
                  cy={100}
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {leadSourceData?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: 11
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2">
              {leadSourceData?.map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-gray-600">{item.name}</span>
                  <span className="text-sm font-medium text-gray-900">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
