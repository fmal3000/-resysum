
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MessageSquare, Mail, FileText, Building2 } from 'lucide-react'

const activities = [
  {
    id: 1,
    type: 'sms_sent',
    description: 'SMS sent to seller at 123 Main St',
    time: '2 hours ago',
    icon: MessageSquare,
    iconColor: 'text-blue-600',
    iconBg: 'bg-blue-100',
  },
  {
    id: 2,
    type: 'property_analyzed',
    description: 'Property analyzed: 456 Oak Ave - Score: 8.2',
    time: '4 hours ago',
    icon: Building2,
    iconColor: 'text-green-600',
    iconBg: 'bg-green-100',
  },
  {
    id: 3,
    type: 'email_sent',
    description: 'Email campaign sent to 24 buyers',
    time: '6 hours ago',
    icon: Mail,
    iconColor: 'text-purple-600',
    iconBg: 'bg-purple-100',
  },
  {
    id: 4,
    type: 'contract_created',
    description: 'Contract generated for 789 Pine St',
    time: '1 day ago',
    icon: FileText,
    iconColor: 'text-orange-600',
    iconBg: 'bg-orange-100',
  },
  {
    id: 5,
    type: 'property_analyzed',
    description: 'Property analyzed: 321 Elm St - Score: 6.8',
    time: '1 day ago',
    icon: Building2,
    iconColor: 'text-green-600',
    iconBg: 'bg-green-100',
  },
]

export function RecentActivity() {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities?.map((activity) => {
            const Icon = activity.icon
            return (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className={`p-2 rounded-lg ${activity.iconBg} flex-shrink-0`}>
                  <Icon className={`h-4 w-4 ${activity.iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900">{activity.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
                <Badge variant="outline" className="text-xs">
                  {activity.type.replace('_', ' ')}
                </Badge>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
