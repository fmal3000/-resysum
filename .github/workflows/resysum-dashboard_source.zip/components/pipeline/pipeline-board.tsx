
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { MoreHorizontal, Phone, Mail, DollarSign } from 'lucide-react'

const stages = [
  { id: 'new', title: 'New Leads', color: 'bg-gray-100 border-gray-200' },
  { id: 'contacted', title: 'Contacted', color: 'bg-blue-100 border-blue-200' },
  { id: 'negotiating', title: 'Negotiating', color: 'bg-yellow-100 border-yellow-200' },
  { id: 'under_contract', title: 'Under Contract', color: 'bg-purple-100 border-purple-200' },
  { id: 'closed', title: 'Closed', color: 'bg-green-100 border-green-200' },
]

const deals = [
  {
    id: 1,
    stage: 'new',
    propertyAddress: '123 Main St',
    sellerName: 'John Smith',
    sellerPhone: '(555) 123-4567',
    arv: 285000,
    priority: 'high',
    daysInStage: 2,
  },
  {
    id: 2,
    stage: 'contacted',
    propertyAddress: '456 Oak Ave',
    sellerName: 'Sarah Johnson',
    sellerPhone: '(555) 234-5678',
    arv: 320000,
    priority: 'medium',
    daysInStage: 5,
  },
  {
    id: 3,
    stage: 'negotiating',
    propertyAddress: '789 Pine St',
    sellerName: 'Mike Wilson',
    sellerPhone: '(555) 345-6789',
    arv: 245000,
    priority: 'high',
    daysInStage: 8,
  },
  {
    id: 4,
    stage: 'under_contract',
    propertyAddress: '321 Elm Dr',
    sellerName: 'Lisa Brown',
    sellerPhone: '(555) 456-7890',
    arv: 198000,
    priority: 'medium',
    daysInStage: 12,
  },
  {
    id: 5,
    stage: 'closed',
    propertyAddress: '654 Maple Ln',
    sellerName: 'Tom Davis',
    sellerPhone: '(555) 567-8901',
    arv: 275000,
    priority: 'low',
    daysInStage: 1,
  },
]

const priorityColors = {
  high: 'bg-red-100 text-red-800',
  medium: 'bg-yellow-100 text-yellow-800',
  low: 'bg-green-100 text-green-800',
}

export function PipelineBoard() {
  return (
    <div className="flex space-x-6 overflow-x-auto pb-6">
      {stages?.map((stage) => {
        const stageDeals = deals?.filter(deal => deal.stage === stage.id)
        
        return (
          <div key={stage.id} className="flex-shrink-0 w-80">
            <Card className={`${stage.color} h-full`}>
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-medium text-gray-700 flex items-center justify-between">
                  {stage.title}
                  <Badge variant="outline" className="ml-2">
                    {stageDeals?.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {stageDeals?.map((deal) => (
                  <Card key={deal.id} className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200 cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900 text-sm">
                            {deal.propertyAddress}
                          </h4>
                          <p className="text-xs text-gray-600">{deal.sellerName}</p>
                        </div>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-500">ARV:</span>
                          <span className="text-sm font-medium">${deal.arv?.toLocaleString()}</span>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <Badge 
                            variant="outline"
                            className={priorityColors[deal.priority as keyof typeof priorityColors]}
                          >
                            {deal.priority}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {deal.daysInStage} days
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-2 pt-2">
                          <Button variant="ghost" size="sm">
                            <Phone className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Mail className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <DollarSign className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        )
      })}
    </div>
  )
}
