
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Play, Pause, Edit, Trash2, BarChart3 } from 'lucide-react'

const campaigns = [
  {
    id: 1,
    name: 'Distressed Property Outreach',
    status: 'active',
    totalSent: 245,
    delivered: 238,
    responses: 44,
    responseRate: 18.5,
    createdAt: '2024-01-15',
  },
  {
    id: 2,
    name: 'Follow-up Sequence',
    status: 'paused',
    totalSent: 156,
    delivered: 152,
    responses: 23,
    responseRate: 15.1,
    createdAt: '2024-01-12',
  },
  {
    id: 3,
    name: 'New Lead Welcome',
    status: 'draft',
    totalSent: 0,
    delivered: 0,
    responses: 0,
    responseRate: 0,
    createdAt: '2024-01-18',
  },
  {
    id: 4,
    name: 'Motivated Seller Campaign',
    status: 'completed',
    totalSent: 387,
    delivered: 381,
    responses: 72,
    responseRate: 18.9,
    createdAt: '2024-01-08',
  },
]

const statusColors = {
  active: 'bg-green-100 text-green-800',
  paused: 'bg-yellow-100 text-yellow-800',
  draft: 'bg-gray-100 text-gray-800',
  completed: 'bg-blue-100 text-blue-800',
}

export function SmsCampaigns() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          SMS Campaigns
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campaign</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent</TableHead>
                <TableHead>Delivered</TableHead>
                <TableHead>Responses</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {campaigns?.map((campaign) => (
                <TableRow key={campaign.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium text-gray-900">{campaign.name}</div>
                      <div className="text-sm text-gray-500">
                        Created {new Date(campaign.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline"
                      className={statusColors[campaign.status as keyof typeof statusColors]}
                    >
                      {campaign.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{campaign.totalSent}</TableCell>
                  <TableCell className="text-sm">{campaign.delivered}</TableCell>
                  <TableCell className="text-sm">{campaign.responses}</TableCell>
                  <TableCell className="text-sm font-medium">
                    {campaign.responseRate}%
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {campaign.status === 'active' ? (
                        <Button variant="ghost" size="sm">
                          <Pause className="h-4 w-4" />
                        </Button>
                      ) : campaign.status === 'paused' ? (
                        <Button variant="ghost" size="sm">
                          <Play className="h-4 w-4" />
                        </Button>
                      ) : null}
                      <Button variant="ghost" size="sm">
                        <BarChart3 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
