
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Copy, Edit, Plus } from 'lucide-react'

const templates = [
  {
    id: 1,
    name: 'Initial Contact',
    preview: 'Hi {name}, I saw your property at {address}. Are you still looking to sell? I can make a cash offer.',
    category: 'outreach',
    usageCount: 45,
  },
  {
    id: 2,
    name: 'Follow-up',
    preview: 'Hi {name}, following up on my previous message about {address}. Would you like to discuss a cash offer?',
    category: 'followup',
    usageCount: 32,
  },
  {
    id: 3,
    name: 'Appointment Setting',
    preview: 'Hi {name}, I\'d like to schedule a quick 15-min call to discuss your property. What time works best?',
    category: 'appointment',
    usageCount: 28,
  },
  {
    id: 4,
    name: 'Offer Presentation',
    preview: 'Hi {name}, based on our conversation, I can offer ${offer_amount} cash for {address}. Interested?',
    category: 'offer',
    usageCount: 18,
  },
]

const categoryColors = {
  outreach: 'bg-blue-100 text-blue-800',
  followup: 'bg-green-100 text-green-800',
  appointment: 'bg-purple-100 text-purple-800',
  offer: 'bg-orange-100 text-orange-800',
}

export function SmsTemplates() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">
            SMS Templates
          </CardTitle>
          <Button size="sm" variant="outline">
            <Plus className="h-4 w-4 mr-2" />
            New
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {templates?.map((template) => (
          <div key={template.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h4 className="font-medium text-sm text-gray-900">{template.name}</h4>
                <Badge 
                  variant="outline" 
                  className={`mt-1 ${categoryColors[template.category as keyof typeof categoryColors]}`}
                >
                  {template.category}
                </Badge>
              </div>
              <div className="flex space-x-1">
                <Button variant="ghost" size="sm">
                  <Copy className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Edit className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-600 mb-2 line-clamp-2">
              {template.preview}
            </p>
            <p className="text-xs text-gray-500">
              Used {template.usageCount} times
            </p>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
